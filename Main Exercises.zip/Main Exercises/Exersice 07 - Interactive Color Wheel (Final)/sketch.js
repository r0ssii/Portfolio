/**
 * @Date:   2020-10-07T11:27:16+01:00
 * @Last modified time: 2020-10-13T14:21:47+01:00
 */



var radius = 150;
var rStart = 0; //The red color starting point variable.
var gStart = 120; //The green color starting point variable.
var bStart = 240; //The blue color starting point variable.

//Setup function
function setup() {
  createCanvas(windowWidth, windowHeight);
  background(255);
  angleMode(DEGREES);
  strokeWeight(radius / 20);
}

//Draw function
function draw() {
  background(255);
  Wheel('red', rStart, width / 2 - radius / 2, height / 2 - radius / 2);
  Wheel('green', gStart, width / 2 + radius / 2, height / 2 - radius / 2);
  Wheel('blue', bStart, width / 2, height / 2 + radius / 3);
  rStart += 1;
  gStart += 1;
  bStart += 1;
}

//Draw Wheel function
function Wheel(c, start, xpos, ypos) {
  for (let i = start; i < start + 360; i++) {
    let color = map(i, start, start + 360, 0, 255);

    if (c == 'red') {
      stroke(color, 0, 0, 30);
    } else if (c == 'green') {
      stroke(0, color, 0, 30);
    } else {
      stroke(0, 0, color, 30);
    }
    let x = xpos + radius * cos(i);
    let y = ypos + radius * sin(i);
    line(xpos, ypos, x, y);
  }
}

// Screenshot function using keyPressed.
function keyPressed() {
  if (key == 's' || key == 'S') {
    saveCanvas(gd.timestamp(), 'png')
  }
}
