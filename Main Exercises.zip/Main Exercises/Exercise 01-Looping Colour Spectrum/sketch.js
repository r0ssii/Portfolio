/**
 * @Date:   2020-09-23T10:22:59+01:00
 * @Last modified time: 2020-09-29T15:02:40+01:00
 */


// Setup fuction
function setup() {
  createCanvas(600, 600);
  colorMode(HSB, width, height, 100);
  noStroke();
  background(0,0,0)
}

// Draw function
function draw() {
  let stepY = mouseX + 1;
  let stepX = mouseY + 1;

  for (let gridY = 0; gridY < height; gridY = gridY + stepY) {
    for (let gridX = 0; gridX < width; gridX = gridX + stepX) {
      fill(gridX, height-gridY, 100);
      rect(gridX, gridY,stepX, stepY);
    }
  }



}

function keyPressed() {
  if (key == 's' || key == 'S') {
    saveCanvas(gd.timestamp(), 'png')
  }
}
