Exercise 02

1. Created variables.
2. Updated the setup function to have angles, fills, background.
3. Changed the angles to degrees.
4. Setup function has beginShape(); and endShape();.
5. Increment each triangle by a particular number.
6. 
