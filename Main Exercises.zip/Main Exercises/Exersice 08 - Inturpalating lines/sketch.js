/**
 * @Date:   2020-09-23T10:22:59+01:00
 * @Last modified time: 2020-10-14T10:39:00+01:00
 */


// Setup fuction
function setup() {
  createCanvas(600, 600);
  colorMode(HSB, width, height, 100);
  noStroke();
  background(255)
}

// Draw function
function draw() {
  beginShape(TRIANGLE_FAN);// Beginign of the shape being created.
  vertex(250, 250);
  for (let i = 0; i <= 360; i += stepAngle) {
    let vx = (radius * cos(i)) + 250;
    let vy = (radius * sin(i)) + 250;
    fill(0,0,0);
    vertex(vx, vy);
  }
  endShape();// End



}
