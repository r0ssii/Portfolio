Exercise 01:

1. Opened the sketch.js file.
2. Create the setup function and draw function.
3. Created two variables with suitable naming convention.
4. Created a for loop so colors are repeated depending on the code that is added.
5. Added this read me file explaining what was done.
