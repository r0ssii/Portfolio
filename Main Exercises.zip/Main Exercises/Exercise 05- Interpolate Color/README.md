Exercise 05

1. Create a starting color.
2. Create an end color.
3. Created a for loop.
4. 
