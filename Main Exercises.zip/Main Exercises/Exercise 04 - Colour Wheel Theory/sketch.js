/**
 * @Date:   2020-09-30T10:13:09+01:00
 * @Last modified time: 2020-10-13T14:12:44+01:00
 */
var r;
var g;
var b;


//Setup function
function setup() {
  createCanvas(500, 500); //Making the canvas
  background(255); // Background of the canvas
  smooth();
  noStroke();
}

//draw function
function draw() {

  r = random(255); // r is a random number between 0 - 255
  g = random(255); // g is a random number betwen 0 - 255
  b = random(255); // b is a random number between 0 - 255

  if (frameCount % 10 == 0) { // This is counting the frames to be equal to 10 unsing modulo.

    fill(r, g, b); //This fills each rect with the r g b variables.
    push();
    translate(200, 200);
    rotate(radians(frameCount * 1 % 360)); //Translates each rect by 1.
    rect(0, 0, 150, 60);
    pop();

  }

}
