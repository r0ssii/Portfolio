/**
 * @Date:   2020-09-30T10:13:09+01:00
 * @Last modified time: 2020-10-06T14:51:14+01:00
 */



//Setup function
function setup() {
  createCanvas(500, 500); //Making the canvas
  background(255); // Background of the canvas
  smooth();
  noStroke();

}

function draw() {

}
