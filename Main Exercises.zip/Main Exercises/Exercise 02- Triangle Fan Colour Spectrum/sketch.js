/**
 * @Date:   2020-09-23T10:22:59+01:00
 * @Last modified time: 2020-09-30T10:34:20+01:00
 */

//Create variables
let numOfSegments = 120;
let stepAngle = 360 / numOfSegments;
let radius = 150;

// Setup fuction
function setup() {
  createCanvas(500, 500);
  colorMode(HSB, 360, 100, 100);
  angleMode(DEGREES);
}

// Draw function
function draw() {
  beginShape(TRIANGLE_FAN);// Beginign of the shape being created.
  vertex(250, 250);
  for (let i = 0; i <= 360; i += stepAngle) {
    let vx = (radius * cos(i)) + 250;
    let vy = (radius * sin(i)) + 250;
    fill(i, 100, 100);
    vertex(vx, vy);
  }
  endShape();// End of shape that is created.
}

function keyPressed() {
  if (key == 's' || key == 'S') {
    saveCanvas(gd.timestamp(), 'png')
  }
}
