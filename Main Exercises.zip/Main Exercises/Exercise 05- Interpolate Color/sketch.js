/**
 * @Date:   2020-09-30T12:20:30+01:00
 * @Last modified time: 2020-10-07T10:33:39+01:00
 */



function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
}

function draw() {
	const clr1 = color(200);
	const clr2 = color(40);

	for (let i = 0; i < width; i += 50) {

		const ratio = map(i, 0, width, 0, 1)
		const middleColor = lerpColor(clr1, clr2, ratio)

		fill(middleColor)
		rect(i, height / 2, 50, 50)
	}
}
