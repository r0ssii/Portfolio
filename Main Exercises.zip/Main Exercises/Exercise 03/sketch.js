/**
 * @Date:   2020-09-30T10:13:09+01:00
 * @Last modified time: 2020-09-30T10:25:07+01:00
 */



// Setup fuction
function setup() {
  createCanvas(500, 500);
  colorMode(HSB, 360, 100, 100);
  angleMode(DEGREES);
  rectMode(CENTER)
}

// Draw function
function draw() {
push();
translate(200,200);
rotate(20);
fill(120,100,100)
rect(0,0,100,200)
pop();

push();
translate(200,200);
rotate(20);
fill(100,100,120)
rect(100,100,100,200)
pop();
}
